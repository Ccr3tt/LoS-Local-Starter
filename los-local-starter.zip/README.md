# Lord of SQLInjection Local Starter

Local Docker starter for the provided LoS-style problem source.

## Run

```bash
docker compose down
docker compose up -d --build
```

Open:

```text
http://127.0.0.1:8080
```

## Notes

- MySQL-based stages use MariaDB.
- Old `mysql_*` calls are wrapped through `mysqli_*` in `web/src/config.php`.
- SQLite-named stages are emulated through MariaDB tables because the PHP 8.2 Docker image may not expose `sqlite3` / `pdo_sqlite` as installable bundled extensions in some builds.
- MSSQL and MongoDB stages are lightweight local emulations, not perfect engine-level recreations.
- This is intentionally vulnerable and should only be run locally for CTF practice.
