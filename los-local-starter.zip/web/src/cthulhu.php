modsec.rubiya.kr server is running ModSecurity Core Rule Set v3.1.0 with paranoia level 1(default).
It is the latest version now.(2019.05)
Can you bypass the WAF?

<?php
  include "./welcome.php";
  include "./config.php";
  login_chk();
  $db = dbconnect();
  if(preg_match('/prob|_|\.|\(\)|admin/i', $_GET[id])) exit("No Hack ~_~");
  if(preg_match('/prob|_|\.|\(\)|admin/i', $_GET[pw])) exit("No Hack ~_~");
  $query = "select id from prob_cthulhu where id='{$_GET[id]}' and pw='{$_GET[pw]}'";
  echo "<hr>query : <strong>{$query}</strong><hr><br>";
  $rows = @mysqli_query($db,$query);
  $result = $rows ? @mysqli_fetch_array($rows) : false;
  if($result && $result['id']) solve("cthulhu");
  highlight_file(__FILE__);
?>
