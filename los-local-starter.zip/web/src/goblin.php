<?php 
  include "./config.php"; 
  login_chk(); 
  $db = dbconnect(); 
  if(!isset($_GET[no]) || $_GET[no] === '') $_GET[no] = '0';
  if(preg_match('/prob|_|\.|\(\)/i', $_GET[no])) exit("No Hack ~_~"); 
  if(preg_match('/\'|\"|\`/i', $_GET[no])) exit("No Quotes ~_~"); 
  $query = "select id from prob_goblin where id='guest' and no={$_GET[no]}"; 
  echo "<hr>query : <strong>{$query}</strong><hr><br>"; 
  $rows = @mysqli_query($db,$query);
  $result = $rows ? @mysqli_fetch_array($rows) : false; 
  if($result && $result['id']) echo "<h2>Hello {$result[id]}</h2>"; 
  if($result && $result['id'] == 'admin') solve("goblin");
  highlight_file(__FILE__); 
?>
