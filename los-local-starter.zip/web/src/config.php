<?php
/*
 * Local Lord of SQLInjection compatibility config.
 * This is intentionally vulnerable for local CTF practice only.
 */
error_reporting(0);
ini_set('display_errors', '0');
if (session_status() === PHP_SESSION_NONE) {
  @session_start();
}

// Old LoS source uses PHP 5-style unquoted array keys like $_GET[id].
// PHP 8 treats those as constants, so define the commonly used constants here.
foreach (array('id','pw','no','order','email','ip','score','shit','joinmail','query','REMOTE_ADDR') as $k) {
  if (!defined($k)) define($k, $k);
}

$poltergeistFlag = getenv('POLTERGEIST_FLAG') ?: 'poltergeist_local_flag';
$krakenFlag = getenv('KRAKEN_FLAG') ?: 'kraken_local_flag';

function login_chk(){
  // Original LoS required login. For local practice we keep it open.
  return true;
}


function los_ensure_local_schema($db){
  static $done = false;
  if ($done) return;

  // Old MSSQL stages are emulated on MariaDB. Some older starter DBs created
  // prob_revenant without an id column, while the original problem queries id/pw.
  // Patch the local schema at runtime so users do not need to delete DB volumes.
  $col = @mysqli_query($db, "SHOW COLUMNS FROM prob_revenant LIKE 'id'");
  if (!$col || mysqli_num_rows($col) === 0) {
    @mysqli_query($db, "DROP TABLE IF EXISTS prob_revenant");
    @mysqli_query($db, "CREATE TABLE prob_revenant (id VARCHAR(80), c1 VARCHAR(80), c2 VARCHAR(80), c3 VARCHAR(80), pw VARCHAR(255)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    @mysqli_query($db, "INSERT INTO prob_revenant VALUES ('guest','a','b','c','guest'),('admin','a','b','c','revenant_admin_pw')");
  }

  @mysqli_query($db, "CREATE TABLE IF NOT EXISTS prob_mummy (id VARCHAR(80), pw VARCHAR(255)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  @mysqli_query($db, "INSERT INTO prob_mummy SELECT 'admin','mummy_admin_pw' WHERE NOT EXISTS (SELECT 1 FROM prob_mummy WHERE id='admin')");

  @mysqli_query($db, "CREATE TABLE IF NOT EXISTS prob_hell_fire (id VARCHAR(80), email VARCHAR(255), score INT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  @mysqli_query($db, "INSERT INTO prob_hell_fire SELECT 'admin','admin_hell_fire@example.local',100 WHERE NOT EXISTS (SELECT 1 FROM prob_hell_fire WHERE id='admin')");

  @mysqli_query($db, "CREATE TABLE IF NOT EXISTS prob_evil_wizard (id VARCHAR(80), email VARCHAR(255), score INT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  @mysqli_query($db, "INSERT INTO prob_evil_wizard SELECT 'admin','admin_evil_wizard@example.local',100 WHERE NOT EXISTS (SELECT 1 FROM prob_evil_wizard WHERE id='admin')");

  $done = true;
}

function dbconnect($ignored_db_name = null){
  static $db = null;
  if ($db instanceof mysqli && @$db->ping()) return $db;

  $host = getenv('DB_HOST') ?: 'db';
  $user = getenv('DB_USER') ?: 'los';
  $pass = getenv('DB_PASS') ?: 'los';
  $name = getenv('DB_NAME') ?: 'los';

  $db = @mysqli_connect($host, $user, $pass, $name);
  if (!$db) {
    http_response_code(500);
    die("DB connect failed. Try: docker compose up -d --build<br>");
  }
  mysqli_set_charset($db, 'utf8mb4');
  los_ensure_local_schema($db);
  $GLOBALS['_LOS_MYSQLI'] = $db;
  return $db;
}

function los_progress_file(){
  $dir = getenv('LOS_DATA_DIR') ?: '/var/los-data';
  if (!is_dir($dir)) {
    @mkdir($dir, 0777, true);
  }
  return rtrim($dir, '/\\') . '/solved.json';
}

function los_read_progress_file(){
  $file = los_progress_file();

  if (!file_exists($file)) {
    @file_put_contents($file, "{}\n", LOCK_EX);
  }

  $raw = @file_get_contents($file);
  $data = json_decode($raw ?: '{}', true);

  if (!is_array($data)) {
    $data = array();
  }

  return $data;
}

function los_write_progress_file($data){
  $file = los_progress_file();
  $dir = dirname($file);

  if (!is_dir($dir)) {
    @mkdir($dir, 0777, true);
  }

  $clean = array();
  foreach ($data as $k => $v) {
    $name = preg_replace('/[^a-zA-Z0-9_]/', '', strval($k));
    if ($name !== '' && $v) {
      $clean[$name] = true;
    }
  }

  @file_put_contents(
    $file,
    json_encode($clean, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n",
    LOCK_EX
  );
  @chmod($file, 0666);
}

function los_mark_solved($name){
  $name = preg_replace('/[^a-zA-Z0-9_]/', '', strval($name));
  if ($name === '') return;

  $_SESSION['solved'][$name] = true;

  $data = los_read_progress_file();
  $data[$name] = true;
  los_write_progress_file($data);
}

function los_load_solved_map(){
  $solved = array();

  $data = los_read_progress_file();
  foreach ($data as $k => $v) {
    if ($v) {
      $solved[$k] = true;
      $_SESSION['solved'][$k] = true;
    }
  }

  if (!empty($_SESSION['solved']) && is_array($_SESSION['solved'])) {
    foreach ($_SESSION['solved'] as $k => $v) {
      if ($v) $solved[$k] = true;
    }
  }

  return $solved;
}

function los_reset_progress(){
  unset($_SESSION['solved']);
  los_write_progress_file(array());
}

function solve($name){
  los_mark_solved($name);
  echo "<div style='padding:12px;margin:10px 0;border:2px solid #2d8a34;background:#eaffea'>";
  echo "<strong>🎉 SOLVED: ".htmlspecialchars($name, ENT_QUOTES, 'UTF-8')."</strong>";
  echo "</div>";
}

// ---- mysql_* compatibility for old LoS code on PHP 7.4+ ----
if (!function_exists('mysql_query')) {
  function mysql_query($query){
    $db = dbconnect();
    $res = @mysqli_query($db, $query);
    $GLOBALS['_LOS_LAST_MYSQL_ERROR'] = mysqli_error($db);
    return $res;
  }
}
if (!function_exists('mysql_fetch_array')) {
  function mysql_fetch_array($result){
    if (!$result) return false;
    return @mysqli_fetch_array($result);
  }
}
if (!function_exists('mysql_error')) {
  function mysql_error(){
    $db = dbconnect();
    return mysqli_error($db);
  }
}

// ---- sqlite_* compatibility for SQLite-based stages ----
// Docker/PHP 8.2 builds can be inconsistent about the old sqlite extension names.
// For local practice, the SQLite stages are backed by MariaDB tables instead.
if (!function_exists('sqlite_open')) {
  function sqlite_open($path){
    $base = basename(strval($path), '.db');
    $base = preg_replace('/[^a-zA-Z0-9_]/', '', $base);
    return array('__los_sqlite_emulated' => true, 'name' => $base);
  }
}
if (!function_exists('sqlite_query')) {
  function sqlite_query($db, $query){
    if (is_array($db) && !empty($db['__los_sqlite_emulated'])) {
      $mysqli = dbconnect();
      $name = $db['name'];
      $mapped = "prob_" . $name . "_member";
      $query = preg_replace('/\bmember\b/i', "`$mapped`", strval($query));
      $res = @mysqli_query($mysqli, $query);
      $GLOBALS['_LOS_LAST_MYSQL_ERROR'] = mysqli_error($mysqli);
      return $res;
    }
    return false;
  }
}
if (!function_exists('sqlite_fetch_array')) {
  function sqlite_fetch_array($result){
    if (!$result) return false;
    if ($result instanceof mysqli_result) return @mysqli_fetch_array($result);
    return false;
  }
}

// ---- lightweight sqlsrv/mssql compatibility using MySQL backend ----
if (!function_exists('mssql_connect')) {
  function mssql_connect($ignored_db_name = null){
    return dbconnect();
  }
}
if (!function_exists('sqlsrv_query')) {
  function sqlsrv_query($db, $query){
    $res = @mysqli_query($db, $query);
    $GLOBALS['_LOS_SQLSRV_ERROR'] = mysqli_error($db);
    return $res;
  }
}
if (!function_exists('sqlsrv_fetch_array')) {
  function sqlsrv_fetch_array($result){
    if (!$result) return false;
    return @mysqli_fetch_array($result);
  }
}
if (!function_exists('sqlsrv_errors')) {
  function sqlsrv_errors(){
    return empty($GLOBALS['_LOS_SQLSRV_ERROR']) ? false : array($GLOBALS['_LOS_SQLSRV_ERROR']);
  }
}
if (!function_exists('mssql_error')) {
  function mssql_error($errors = null){
    if (is_array($errors)) return implode(" | ", $errors);
    return strval($errors);
  }
}

// ---- tiny MongoDB-like adapter backed by MySQL for simple exact-match stages ----
class LosMongoCursor {
  private $rows;
  private $idx = 0;
  public function __construct($rows){ $this->rows = $rows; }
  public function next(){
    if ($this->idx >= count($this->rows)) return false;
    return $this->rows[$this->idx++];
  }
}
class LosMongoCollection {
  private $name;
  public function __construct($name){ $this->name = $name; }

  public function find($query){
    $db = dbconnect();
    $table = preg_replace('/[^a-zA-Z0-9_]/', '', $this->name);

    // Exact-match emulation for {"id": "...", "pw": "..."} queries.
    if (isset($query['id']) || isset($query['pw'])) {
      $where = array();
      foreach (array('id','pw') as $k) {
        if (array_key_exists($k, $query)) {
          $where[] = "`$k`='" . mysqli_real_escape_string($db, strval($query[$k])) . "'";
        }
      }
      $sql = "select * from `$table`";
      if ($where) $sql .= " where " . implode(" and ", $where);
      $res = @mysqli_query($db, $sql);
      $rows = array();
      if ($res) while ($r = mysqli_fetch_array($res)) $rows[] = $r;
      return new LosMongoCursor($rows);
    }

    // Very small $where sandbox for local practice; not a real MongoDB JS engine.
    if (isset($query['$where'])) {
      $where = strval($query['$where']);
      if (stripos($where, 'return true') !== false || preg_match('/\|\|\s*1/', $where)) {
        $res = @mysqli_query($db, "select * from `$table`");
        $rows = array();
        if ($res) while ($r = mysqli_fetch_array($res)) $rows[] = $r;
        return new LosMongoCursor($rows);
      }
    }

    return new LosMongoCursor(array());
  }
}
class LosMongoDb {
  public function __get($name){ return new LosMongoCollection($name); }
}
if (!function_exists('mongodb_connect')) {
  function mongodb_connect(){ return new LosMongoDb(); }
}
if (!function_exists('mongodb_fetch_array')) {
  function mongodb_fetch_array($cursor){
    if ($cursor instanceof LosMongoCursor) return $cursor->next();
    return false;
  }
}
?>
