<?php
require_once __DIR__ . '/config.php';

$reset = isset($_GET['reset']);
if ($reset) {
  los_reset_progress();
  header('Location: /');
  exit;
}

$solvedMap = los_load_solved_map();

$problems = [
  ['gremlin', 'GREMLIN', 'gremlin.php'],
  ['cobolt', 'COBOLT', 'cobolt.php'],
  ['goblin', 'GOBLIN', 'goblin.php'],
  ['orc', 'ORC', 'orc.php'],
  ['wolfman', 'WOLFMAN', 'wolfman.php'],
  ['darkelf', 'DARKELF', 'darkelf.php'],
  ['orge', 'Orge', 'orge.php'],
  ['troll', 'TROLL', 'troll.php'],
  ['vampire', 'VAMPIRE', 'vampire.php'],
  ['skeleton', 'SKELETON', 'skeleton.php'],
  ['golem', 'GOLEM', 'golem.php'],
  ['darkknight', 'DARKKNIGHT', 'darkknight.php'],
  ['bugbear', 'BUGBEAR', 'bugbear.php'],
  ['giant', 'GIANT', 'giant.php'],
  ['assassin', 'ASSASSIN', 'assassin.php'],
  ['succubus', 'SUCCUBUS', 'succubus.php'],
  ['zombie_assassin', 'ZOMBIE ASSASSIN', 'zombie_assassin.php'],
  ['nightmare', 'NIGHTMARE', 'nightmare.php'],
  ['xavis', 'Xavis', 'xavis.php'],
  ['dragon', 'DRAGON', 'dragon.php'],
  ['iron_golem', 'IRON_GOLEM', 'iron_golem.php'],
  ['dark_eyes', 'DARK_EYES', 'dark_eyes.php'],
  ['hell_fire', 'HELL_FIRE', 'hell_fire.php'],
  ['evil_wizard', 'EVIL_WIZARD', 'evil_wizard.php'],
  ['green_dragon', 'GREEN_DRAGON', 'green_dragon.php'],
  ['red_dragon', 'RED_DRAGON', 'red_dragon.php'],
  ['blue_dragon', 'BLUE_DRAGON', 'blue_dragon.php'],
  ['frankenstein', 'FRANKENSTEIN', 'frankenstein.php'],
  ['phantom', 'PHANTOM', 'phantom.php'],
  ['ouroboros', 'OUROBOROS', 'ouroboros.php'],
  ['zombie', 'ZOMBIE', 'zombie.php'],
  ['alien', 'ALIEN', 'alien.php'],
  ['cthulhu', 'CTHULHU', 'cthulhu.php'],
  ['death', 'DEATH', 'death.php'],
  ['godzilla', 'GODZILLA', 'godzilla.php'],
  ['cyclops', 'CYCLOPS', 'cyclops.php'],
  ['chupacabra', 'CHUPACABRA', 'chupacabra.php'],
  ['manticore', 'MANTICORE', 'manticore.php'],
  ['banshee', 'BANSHEE', 'banshee.php'],
  ['poltergeist', 'POLTERGEIST', 'poltergeist.php'],
  ['nessie', 'NESSIE', 'nessie.php'],
  ['revenant', 'REVENANT', 'revenant.php'],
  ['yeti', 'YETI', 'yeti.php'],
  ['mummy', 'MUMMY', 'mummy.php'],
  ['kraken', 'KRAKEN', 'kraken.php'],
  ['cerberus', 'CERBERUS', 'cerberus.php'],
  ['siren', 'SIREN', 'siren.php'],
  ['incubus', 'INCUBUS', 'incubus.php'],
];
?>
<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <title>Local Lord of SQLInjection</title>
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      max-width: 980px;
      margin: 32px auto;
      line-height: 1.5;
    }

    table {
      border-collapse: collapse;
      width: 100%;
      table-layout: fixed;
    }

    th,
    td {
      border: 1px solid #ddd;
      padding: 8px;
    }

    th {
      background: #f5f5f5;
    }

    th:nth-child(1),
    td:nth-child(1) {
      width: 48px;
      text-align: center;
    }

    th:nth-child(2),
    td:nth-child(2) {
      width: auto;
    }

    th:nth-child(3),
    td:nth-child(3) {
      width: 76px;
      text-align: center;
    }

    a {
      color: #111;
      text-decoration: none;
    }

    a:hover {
      color: #111;
      text-decoration: none;
    }

    .problem-link.solved {
      text-decoration: line-through;
      text-decoration-thickness: 2px;
    }

    code {
      background: #f6f8fa;
      padding: 2px 4px;
      border-radius: 4px;
    }

    .note {
      padding: 12px;
      border: 1px solid #ddd;
      background: #fffbe6;
      margin-bottom: 16px;
    }
  </style>
</head>
<body>
<h1>Local Lord of SQLInjection</h1>
<div class="note">
  <p>Rubiya 선생님께서 상업적으로 사용하는게 아닌것이라면 자유롭게 사용해도 좋다고 하셨습니다. 찬양합시다. GOD Rubiya</p>
  <p>Rubiya said that as long as it is not used commercially, we are free to use it. Let us praise him. GOD Rubiya.</p>
  <p>for example: <code>/gremlin.php?id=guest&pw=guest</code></p>
  <p><a href="/?reset=1" onclick="return confirm('Are you sure?');">RESET</a></p>
</div>
<table>
  <tr>
    <th>#</th>
    <th>Problem</th>
    <th>Solved</th>
  </tr>
  <?php foreach ($problems as $idx => $problem): ?>
    <?php
      [$key, $title, $href] = $problem;
      $isSolved = !empty($solvedMap[$key]);
    ?>
    <tr>
      <td><?php echo $idx + 1; ?></td>
      <td>
        <a class="problem-link<?php echo $isSolved ? ' solved' : ''; ?>" href="/<?php echo htmlspecialchars($href, ENT_QUOTES, 'UTF-8'); ?>">
          <?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?>
        </a>
      </td>
      <td><?php echo $isSolved ? '✅' : ''; ?></td>
    </tr>
  <?php endforeach; ?>
</table>
</body>
</html>
