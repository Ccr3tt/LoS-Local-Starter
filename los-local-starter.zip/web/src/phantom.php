<?php  
  include "./config.php";
  login_chk();
  dbconnect("phantom");

  if($_GET['joinmail']){
    $query = "insert into prob_phantom values(0,'{$_SERVER[REMOTE_ADDR]}','{$_GET[joinmail]}')";
    mysql_query($query);
    echo "<hr>query : <strong>{$query}</strong><hr>";
  }

  $rows = mysql_query("select no,ip,email from prob_phantom where no=1 or ip='{$_SERVER[REMOTE_ADDR]}'");
  echo "<table border=1><tr><th>ip</th><th>email</th></tr>";
    while(($result = mysql_fetch_array($rows))){
    if($result['no'] == 1) $result['email'] = "**************";
    echo "<tr><td>{$result[ip]}</td><td>{$result[email]}</td></tr>";
  }
  echo "</table>";

  $_GET[email] = addslashes($_GET[email]);
  $query = "select email from prob_phantom where no=1 and email='{$_GET[email]}'";
  $result = @mysql_fetch_array(mysql_query($query));
  if(($result['email']) && ($result['email'] === $_GET['email'])){ mysql_query("delete from prob_phantom where no != 1"); mysql_query("alter table prob_phantom AUTO_INCREMENT=2"); solve("phantom"); }
  highlight_file(__FILE__);
?>
