SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS prob_gremlin (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_gremlin VALUES ('guest','guest'),('admin','gremlin_admin_pw');

CREATE TABLE IF NOT EXISTS prob_cobolt (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_cobolt VALUES ('guest',MD5('guest')),('admin',MD5('cobolt_admin_pw'));

CREATE TABLE IF NOT EXISTS prob_goblin (id VARCHAR(80), no INT);
INSERT INTO prob_goblin VALUES ('guest',1),('admin',2);

CREATE TABLE IF NOT EXISTS prob_orc (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_orc VALUES ('admin','orc_admin_pw');

CREATE TABLE IF NOT EXISTS prob_wolfman (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_wolfman VALUES ('guest','guest'),('admin','wolfman_admin_pw');

CREATE TABLE IF NOT EXISTS prob_darkelf (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_darkelf VALUES ('guest','guest'),('admin','darkelf_admin_pw');

CREATE TABLE IF NOT EXISTS prob_orge (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_orge VALUES ('guest','guest'),('admin','orge_admin_pw');

CREATE TABLE IF NOT EXISTS prob_troll (id VARCHAR(80));
INSERT INTO prob_troll VALUES ('guest'),('admin');

CREATE TABLE IF NOT EXISTS prob_vampire (id VARCHAR(80));
INSERT INTO prob_vampire VALUES ('guest'),('admin');

CREATE TABLE IF NOT EXISTS prob_skeleton (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_skeleton VALUES ('guest','guest'),('admin','skeleton_admin_pw');

CREATE TABLE IF NOT EXISTS prob_golem (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_golem VALUES ('guest','guest'),('admin','golem_admin_pw');

CREATE TABLE IF NOT EXISTS prob_darkknight (id VARCHAR(80), pw VARCHAR(255), no INT);
INSERT INTO prob_darkknight VALUES ('guest','guest',1),('admin','darkknight_admin_pw',2);

CREATE TABLE IF NOT EXISTS prob_bugbear (id VARCHAR(80), pw VARCHAR(255), no INT);
INSERT INTO prob_bugbear VALUES ('guest','guest',1),('admin','bugbear_admin_pw',2);

CREATE TABLE IF NOT EXISTS prob_giant (dummy INT);
INSERT INTO prob_giant VALUES (1);

CREATE TABLE IF NOT EXISTS prob_assassin (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_assassin VALUES ('guest','guest_pw'),('admin','assassin_admin_pw');

CREATE TABLE IF NOT EXISTS prob_succubus (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_succubus VALUES ('guest','guest'),('admin','succubus_admin_pw');

CREATE TABLE IF NOT EXISTS prob_zombie_assassin (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_zombie_assassin VALUES ('guest','guest'),('admin','zombie_assassin_admin_pw');

CREATE TABLE IF NOT EXISTS prob_nightmare (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_nightmare VALUES ('guest','guest'),('admin','nightmare_admin_pw');

CREATE TABLE IF NOT EXISTS prob_xavis (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_xavis VALUES ('admin','xavis_admin_pw');

CREATE TABLE IF NOT EXISTS prob_dragon (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_dragon VALUES ('guest','guest'),('admin','dragon_admin_pw');

CREATE TABLE IF NOT EXISTS prob_iron_golem (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_iron_golem VALUES ('admin','iron_golem_admin_pw');

CREATE TABLE IF NOT EXISTS prob_dark_eyes (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_dark_eyes VALUES ('admin','dark_eyes_admin_pw');

CREATE TABLE IF NOT EXISTS prob_hell_fire (id VARCHAR(80), email VARCHAR(255), score INT);
INSERT INTO prob_hell_fire VALUES ('guest','guest@example.local',10),('admin','admin_hell_fire@example.local',100),('test','test@example.local',50);

CREATE TABLE IF NOT EXISTS prob_evil_wizard (id VARCHAR(80), email VARCHAR(255), score INT);
INSERT INTO prob_evil_wizard VALUES ('guest','guest@example.local',10),('admin','admin_evil_wizard@example.local',100),('test','test@example.local',50);

CREATE TABLE IF NOT EXISTS prob_green_dragon (id VARCHAR(255), pw VARCHAR(255));
INSERT INTO prob_green_dragon VALUES ('guest','guest'),('admin','green_dragon_admin_pw');

CREATE TABLE IF NOT EXISTS prob_red_dragon (id VARCHAR(80), no BIGINT, pw VARCHAR(255));
INSERT INTO prob_red_dragon VALUES ('guest',1,'guest'),('admin',2,'red_dragon_admin_pw');

CREATE TABLE IF NOT EXISTS prob_blue_dragon (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_blue_dragon VALUES ('guest','guest'),('admin','blue_dragon_admin_pw');

CREATE TABLE IF NOT EXISTS prob_frankenstein (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_frankenstein VALUES ('frankenstein','monster'),('admin','frankenstein_admin_pw');

CREATE TABLE IF NOT EXISTS prob_phantom (no INT AUTO_INCREMENT PRIMARY KEY, ip VARCHAR(80), email VARCHAR(255));
INSERT INTO prob_phantom(no,ip,email) VALUES (1,'127.0.0.1','admin_phantom@example.local');

CREATE TABLE IF NOT EXISTS prob_ouroboros (pw VARCHAR(255));
INSERT INTO prob_ouroboros VALUES ('ouroboros_local_pw');

CREATE TABLE IF NOT EXISTS prob_zombie (pw VARCHAR(255));
INSERT INTO prob_zombie VALUES ('zombie_local_pw');

CREATE TABLE IF NOT EXISTS prob_alien (no BIGINT, id VARCHAR(80));
INSERT INTO prob_alien VALUES (1,'guest'),(2,'admin'),(3,'alien');

CREATE TABLE IF NOT EXISTS prob_cthulhu (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_cthulhu VALUES ('guest','guest'),('admin','cthulhu_admin_pw');

CREATE TABLE IF NOT EXISTS prob_death (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_death VALUES ('guest',MD5('guest')),('admin',MD5('death_admin_pw'));

CREATE TABLE IF NOT EXISTS prob_godzilla (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_godzilla VALUES ('admin','godzilla_admin_pw');

CREATE TABLE IF NOT EXISTS prob_cyclops (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_cyclops VALUES ('guest','guest');

CREATE TABLE IF NOT EXISTS prob_nessie (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_nessie VALUES ('guest','guest'),('admin','nessie_admin_pw');

CREATE TABLE IF NOT EXISTS prob_revenant (id VARCHAR(80), c1 VARCHAR(80), c2 VARCHAR(80), c3 VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_revenant VALUES ('guest','a','b','c','guest'),('admin','a','b','c','revenant_admin_pw');

CREATE TABLE IF NOT EXISTS prob_yeti (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_yeti VALUES ('guest','guest'),('admin','yeti_admin_pw');

CREATE TABLE IF NOT EXISTS prob_mummy (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_mummy VALUES ('guest','guest'),('admin','mummy_admin_pw');

CREATE TABLE IF NOT EXISTS member (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO member VALUES ('guest','guest'),('admin','kraken_local_flag');

CREATE TABLE IF NOT EXISTS prob_cerberus (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_cerberus VALUES ('guest','guest'),('admin','cerberus_admin_pw');

CREATE TABLE IF NOT EXISTS prob_siren (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_siren VALUES ('guest','guest'),('admin','siren_admin_pw');

CREATE TABLE IF NOT EXISTS prob_incubus (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_incubus VALUES ('guest','guest'),('admin','incubus_admin_pw');

-- SQLite-stage emulation tables used by config.php
CREATE TABLE IF NOT EXISTS prob_chupacabra_member (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_chupacabra_member VALUES ('guest','guest'),('admin','chupacabra_admin_pw');

CREATE TABLE IF NOT EXISTS prob_manticore_member (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_manticore_member VALUES ('guest','guest'),('admin','manticore_admin_pw');

CREATE TABLE IF NOT EXISTS prob_poltergeist_member (id VARCHAR(80), pw VARCHAR(255));
INSERT INTO prob_poltergeist_member VALUES ('guest','guest'),('admin','poltergeist_local_flag');
